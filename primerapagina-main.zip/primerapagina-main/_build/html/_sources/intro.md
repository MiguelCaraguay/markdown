# Welcome to your Jupyter Book

This is a small sample book to give you a feel for how book content is
structured.

:::{note}
Here is a note!
:::

And here is a code block:
SOFIA PRUEBA

```
e = mc^2
```

Check out the content pages bundled with this sample book to see more.
