# Listado Materias

Sabes cuales son las materias que estas cursando.

:::{note}
Es importante que sepas tus horarios!
:::